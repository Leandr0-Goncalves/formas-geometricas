﻿using System;

namespace AulaAPS
{
    public class TrianguloIsosceles : Triangulo
    {
        private double _base;
        public double Base
        {
            get { return _base; }
            set { _base = value; }
        }

        private double lado;

        public double Lado
        {
            get { return lado; }
            set { lado = value; }
        }

        public override double CalcularArea()
        {
          
            double altura = Math.Sqrt(Math.Pow(lado, 2) - Math.Pow(Base / 2, 2));
            return (Base * altura) / 2;
        }

        public override double CalcularPerimetro()
        {
            return 2 * lado + Base;
        }

        public override string ToString()
        {
            return $"Triângulo Isósceles (Base: {_base}, Lado: {lado})";
        }
    }
}
