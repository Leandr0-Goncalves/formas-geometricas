﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace AulaAPS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cmbForma_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbForma.Text)
            {
                case "Quadrado":
                    SelecionarQuadrado();
                    break;
                case "Retângulo":
                    SelecionarRetangulo();
                    break;
                case "Circunferência":
                    SelecionarCircunferencia();
                    break;
                case "Triângulo":
                    SelecionarTriangulo();
                    break;
                default:
                    break;
            }
        }

        private void cmbTriangulo_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbTriangulo.Text)
            {
                
                case "Equilátero":
                    SelecionarEquilatero();
                    break;
                case "Isósceles":
                    SelecionarIsosceles();
                    break;
                case "Reto":
                    SelecionarReto();
                    break;
                default:
                    break;
            }
        }

        private void SelecionarQuadrado()
        {
            ExibirBase(true);
            ExibirAltura(false);
            ExibirRaio(false);
            cmbTriangulo.Visible = false;
        }

        private void SelecionarRetangulo()
        {
            ExibirBase(true);
            ExibirAltura(true);
            ExibirRaio(false);
            cmbTriangulo.Visible = false;
        }

        private void SelecionarCircunferencia()
        {
            ExibirBase(false);
            ExibirAltura(false);
            ExibirRaio(true);
            cmbTriangulo.Visible = false;
        }

        private void SelecionarTriangulo()
        {
            ExibirBase(true);
            ExibirAltura(true);
            ExibirRaio(false);
            cmbTriangulo.Visible = true;
        }

        private void SelecionarEquilatero()
        {
            ExibirBase(true);
            ExibirAltura(false);
            ExibirRaio(false);
        }

        private void SelecionarIsosceles()
        {
            ExibirBase(true);
            ExibirAltura(true);
            ExibirRaio(false);

        }

        private void SelecionarReto()
        {
            ExibirBase(true);
            ExibirAltura(true);
            ExibirRaio(false);
        }

        private void ExibirBase(bool visivel)
        {
            lblBase.Visible = txtBase.Visible = visivel;
        }

        private void ExibirAltura(bool visivel)
        {
            lblAltura.Visible = txtAltura.Visible = visivel;
        }

        private void ExibirRaio(bool visivel)
        {
            lblRaio.Visible = txtRaio.Visible = visivel;
        }


        private void btnCriar_Click(object sender, EventArgs e)
        {
            try
            {
                double valorBase = 0, valorAltura = 0, valorRaio = 0;

                if (txtBase.Visible && !string.IsNullOrWhiteSpace(txtBase.Text))
                {
                    valorBase = Convert.ToDouble(txtBase.Text.Replace(",", "."), CultureInfo.InvariantCulture);
                }

                if (txtAltura.Visible && !string.IsNullOrWhiteSpace(txtAltura.Text))
                {
                    valorAltura = Convert.ToDouble(txtAltura.Text.Replace(",", "."), CultureInfo.InvariantCulture);
                }

                if (txtRaio.Visible && !string.IsNullOrWhiteSpace(txtRaio.Text))
                {
                    valorRaio = Convert.ToDouble(txtRaio.Text.Replace(",", "."), CultureInfo.InvariantCulture);
                }



                if (cmbForma.Text.Equals("Quadrado"))
                {
                    FormaGeometrica quadrado = new Quadrado()
                    {
                        Lado = valorBase
                    };
                    cmbObjetos.Items.Add(quadrado);
                    cmbObjetos.SelectedItem = quadrado;
                }


                else if (cmbForma.Text.Equals("Retângulo"))
                {
                    FormaGeometrica retangulo = new Retangulo()
                    {
                        Base = valorBase,
                        Altura = valorAltura
                    };
                    cmbObjetos.Items.Add(retangulo);
                    cmbObjetos.SelectedItem = retangulo;
                }


                else if (cmbForma.Text.Equals("Circunferência"))
                {
                    FormaGeometrica circunferencia = new Circunferencia()
                    {
                        Raio = valorRaio
                    };
                    cmbObjetos.Items.Add(circunferencia);
                    cmbObjetos.SelectedItem = circunferencia;
                }


                else if (cmbTriangulo.Text.Equals("Equilátero"))
                {
                    FormaGeometrica Equilatero = new TrianguloEquilatero()
                    {
                        Base = valorBase
                    };
                    cmbObjetos.Items.Add(Equilatero);
                    cmbObjetos.SelectedItem = Equilatero;
                }


                else if (cmbTriangulo.Text.Equals("Isósceles"))
                {
                    double lado = valorAltura;
                    double baseTriangulo = valorBase;


                    if (lado <= (baseTriangulo / 2))
                    {
                        MessageBox.Show("O lado deve ser maior que a metade da base para formar um triângulo.");
                        return;
                    }

                    double alturaCalculada = Math.Sqrt(Math.Pow(lado, 2) - Math.Pow(baseTriangulo / 2, 2));

                    FormaGeometrica Isosceles = new TrianguloIsosceles()
                    {
                        Base = baseTriangulo,
                        Lado = lado
                    };

                    txtAltura.Text = alturaCalculada.ToString("F2");
                    cmbObjetos.Items.Add(Isosceles);
                    cmbObjetos.SelectedItem = Isosceles; 
                }


                else if (cmbTriangulo.Text.Equals("Reto"))
                {
                    FormaGeometrica Reto = new TrianguloReto()
                    {
                        Base = valorBase,
                        Altura = valorAltura
                    };
                    cmbObjetos.Items.Add(Reto);
                    cmbObjetos.SelectedItem = Reto;
                }
            }


            catch (FormatException)
            {
                MessageBox.Show("Insira valores válidos nos campos de entrada!");
            }
        }



        private void cmbObjetos_SelectedIndexChanged(object sender, EventArgs e)
        {
            FormaGeometrica obj = cmbObjetos.SelectedItem as FormaGeometrica;
            txtArea.Text = obj.CalcularArea().ToString("F2");
            txtPerimetro.Text = obj.CalcularPerimetro().ToString("F2");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CultureInfo.CurrentCulture = new CultureInfo("pt-BR");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Você realmente deseja sair?", "Saindo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.No)
            {
               
                e.Cancel = true;
            }
        }

    }
}
