﻿namespace AulaAPS
{
    public abstract class Triangulo : FormaGeometrica
    {
      
    }
}
